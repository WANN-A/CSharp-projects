﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Notepad
{
    public partial class Parent : Form
    {
        public Parent()
        {
            InitializeComponent();
        }

        //新建
        private void ToolStripMenuItem_add_Click(object sender, EventArgs e)
        {
            //实例化一个子窗体对象
            Child child = new Child();
            //设置子窗体的父窗体
            child.MdiParent = this;
            //打开子窗体
            child.Show();
        }

        //关闭
        private void ToolStripMenuItem_close_Click(object sender, EventArgs e)
        {
            Form frm = this.ActiveMdiChild;//当前活跃的子窗体
            frm.Close();//然后关闭
        }

        //关闭全部
        private void ToolStripMenuItem_closeall_Click(object sender, EventArgs e)
        {
            //this.MdiChildren 获取父窗体中 子窗体的集合
            foreach (Form form in this.MdiChildren)
            {
                Form frm = this.ActiveMdiChild;
                frm.Close();
            }
        }

        //退出
        private void ToolStripMenuItem_exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
