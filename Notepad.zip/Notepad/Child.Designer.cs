﻿
namespace Notepad
{
    partial class Child
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.toolStrip = new System.Windows.Forms.ToolStrip();
            this.toolStripButton_open = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton_save = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton_bold = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton_italic = new System.Windows.Forms.ToolStripButton();
            this.toolStripComboBox_fonts = new System.Windows.Forms.ToolStripComboBox();
            this.toolStripComboBox_size = new System.Windows.Forms.ToolStripComboBox();
            this.textBox_note = new System.Windows.Forms.TextBox();
            this.openFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.saveFileDialog = new System.Windows.Forms.SaveFileDialog();
            this.toolStripLabelmaker = new System.Windows.Forms.ToolStripLabel();
            this.toolStripButton_add = new System.Windows.Forms.ToolStripButton();
            this.toolStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // toolStrip
            // 
            this.toolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton_add,
            this.toolStripButton_open,
            this.toolStripButton_save,
            this.toolStripButton_bold,
            this.toolStripButton_italic,
            this.toolStripComboBox_fonts,
            this.toolStripComboBox_size,
            this.toolStripLabelmaker});
            this.toolStrip.Location = new System.Drawing.Point(3, 3);
            this.toolStrip.Name = "toolStrip";
            this.toolStrip.Size = new System.Drawing.Size(694, 40);
            this.toolStrip.TabIndex = 0;
            this.toolStrip.Text = "toolStrip1";
            // 
            // toolStripButton_open
            // 
            this.toolStripButton_open.Image = global::Notepad.Properties.Resources.file_open;
            this.toolStripButton_open.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton_open.Name = "toolStripButton_open";
            this.toolStripButton_open.Size = new System.Drawing.Size(36, 37);
            this.toolStripButton_open.Text = "打开";
            this.toolStripButton_open.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolStripButton_open.Click += new System.EventHandler(this.toolStripButton_open_Click);
            // 
            // toolStripButton_save
            // 
            this.toolStripButton_save.Image = global::Notepad.Properties.Resources.file_save;
            this.toolStripButton_save.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton_save.Name = "toolStripButton_save";
            this.toolStripButton_save.Size = new System.Drawing.Size(36, 37);
            this.toolStripButton_save.Text = "保存";
            this.toolStripButton_save.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolStripButton_save.Click += new System.EventHandler(this.toolStripButton_save_Click);
            // 
            // toolStripButton_bold
            // 
            this.toolStripButton_bold.Image = global::Notepad.Properties.Resources.text_bold;
            this.toolStripButton_bold.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton_bold.Name = "toolStripButton_bold";
            this.toolStripButton_bold.Size = new System.Drawing.Size(36, 37);
            this.toolStripButton_bold.Text = "加粗";
            this.toolStripButton_bold.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolStripButton_bold.Click += new System.EventHandler(this.toolStripButton_bold_Click);
            // 
            // toolStripButton_italic
            // 
            this.toolStripButton_italic.Image = global::Notepad.Properties.Resources.text_italic;
            this.toolStripButton_italic.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton_italic.Name = "toolStripButton_italic";
            this.toolStripButton_italic.Size = new System.Drawing.Size(36, 37);
            this.toolStripButton_italic.Text = "倾斜";
            this.toolStripButton_italic.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolStripButton_italic.Click += new System.EventHandler(this.toolStripButton_italic_Click);
            // 
            // toolStripComboBox_fonts
            // 
            this.toolStripComboBox_fonts.Name = "toolStripComboBox_fonts";
            this.toolStripComboBox_fonts.Size = new System.Drawing.Size(121, 40);
            this.toolStripComboBox_fonts.Text = "字体";
            this.toolStripComboBox_fonts.SelectedIndexChanged += new System.EventHandler(this.toolStripComboBox_fonts_SelectedIndexChanged);
            // 
            // toolStripComboBox_size
            // 
            this.toolStripComboBox_size.Items.AddRange(new object[] {
            "10",
            "12",
            "14",
            "16",
            "18",
            "20",
            "22",
            "24",
            "26",
            "28",
            "30"});
            this.toolStripComboBox_size.Name = "toolStripComboBox_size";
            this.toolStripComboBox_size.Size = new System.Drawing.Size(121, 40);
            this.toolStripComboBox_size.Text = "10";
            this.toolStripComboBox_size.SelectedIndexChanged += new System.EventHandler(this.toolStripComboBox_size_SelectedIndexChanged);
            this.toolStripComboBox_size.TextChanged += new System.EventHandler(this.toolStripComboBox_size_TextChanged);
            // 
            // textBox_note
            // 
            this.textBox_note.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_note.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox_note.Location = new System.Drawing.Point(3, 43);
            this.textBox_note.Multiline = true;
            this.textBox_note.Name = "textBox_note";
            this.textBox_note.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBox_note.Size = new System.Drawing.Size(694, 411);
            this.textBox_note.TabIndex = 1;
            this.textBox_note.TextChanged += new System.EventHandler(this.textBox_note_TextChanged);
            // 
            // openFileDialog
            // 
            this.openFileDialog.FileName = "openFileDialog";
            // 
            // toolStripLabelmaker
            // 
            this.toolStripLabelmaker.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.toolStripLabelmaker.Name = "toolStripLabelmaker";
            this.toolStripLabelmaker.Size = new System.Drawing.Size(0, 37);
            // 
            // toolStripButton_add
            // 
            this.toolStripButton_add.Image = global::Notepad.Properties.Resources.page_add;
            this.toolStripButton_add.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton_add.Name = "toolStripButton_add";
            this.toolStripButton_add.Size = new System.Drawing.Size(36, 37);
            this.toolStripButton_add.Text = "新建";
            this.toolStripButton_add.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolStripButton_add.Click += new System.EventHandler(this.toolStripButton_add_Click);
            // 
            // Child
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(700, 457);
            this.Controls.Add(this.textBox_note);
            this.Controls.Add(this.toolStrip);
            this.Name = "Child";
            this.Padding = new System.Windows.Forms.Padding(3);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Child_FormClosing);
            this.Load += new System.EventHandler(this.Child_Load);
            this.toolStrip.ResumeLayout(false);
            this.toolStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip toolStrip;
        private System.Windows.Forms.ToolStripButton toolStripButton_open;
        private System.Windows.Forms.ToolStripButton toolStripButton_save;
        private System.Windows.Forms.ToolStripButton toolStripButton_bold;
        private System.Windows.Forms.ToolStripButton toolStripButton_italic;
        private System.Windows.Forms.ToolStripComboBox toolStripComboBox_fonts;
        private System.Windows.Forms.ToolStripComboBox toolStripComboBox_size;
        private System.Windows.Forms.TextBox textBox_note;
        private System.Windows.Forms.OpenFileDialog openFileDialog;
        private System.Windows.Forms.SaveFileDialog saveFileDialog;
        private System.Windows.Forms.ToolStripLabel toolStripLabelmaker;
        private System.Windows.Forms.ToolStripButton toolStripButton_add;
    }
}