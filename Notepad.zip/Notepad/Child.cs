﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//加载的命名空间
using System.Drawing.Text;
using System.Collections;
using System.IO;

namespace Notepad
{
    public partial class Child : Form
    {
        public Child()
        {
            InitializeComponent();
        }

        //窗体加载事件
        private void Child_Load(object sender, EventArgs e)
        {
            //窗体加载时，要加载系统字体
            InstalledFontCollection myFonts = new InstalledFontCollection();
            //获取InstalledFontCollection对象的数组
            FontFamily[] ff = myFonts.Families;
            //声明一个arrlist变量
            ArrayList list = new ArrayList();
            //获取系统数组的列表中集合的长度
            int count = ff.Length;

            //将系统字体名称 添加到 控件中
            for(int i=0;i<count;i++)
            {
                string FontName = ff[i].Name;
                toolStripComboBox_fonts.Items.Add(FontName);
            }
        }

        //加粗
        private void toolStripButton_bold_Click(object sender, EventArgs e)
        {
            //点击按钮 加粗  ，再点击一次  取消加粗
            if (textBox_note.Font.Bold == false)
            {
                textBox_note.Font = new Font(textBox_note.Font, FontStyle.Bold);
            }
            else
            {
                textBox_note.Font = new Font(textBox_note.Font, FontStyle.Regular);
            }
        }

        //倾斜
        private void toolStripButton_italic_Click(object sender, EventArgs e)
        {
            if (textBox_note.Font.Italic == false)
            {
                textBox_note.Font = new Font(textBox_note.Font, FontStyle.Italic);
            }
            else
            {
                textBox_note.Font = new Font(textBox_note.Font, FontStyle.Regular);
            }
        }

        //通过索引事件  改变选择字体
        private void toolStripComboBox_fonts_SelectedIndexChanged(object sender, EventArgs e)
        {
            string fontName = toolStripComboBox_fonts.Text;//取得字体名称
            float fontSize = float.Parse(toolStripComboBox_size.Text);//str转化成float类型，  取得字体大小
            textBox_note.Font = new Font(fontName,fontSize);//设置字体（包括 字体类型（名称）和 字体大小）
        }

        //通过索引事件  改变字体大小
        private void toolStripComboBox_size_SelectedIndexChanged(object sender, EventArgs e)
        {
            string fontName = toolStripComboBox_fonts.Text;//取得字体名称
            float fontSize = float.Parse(toolStripComboBox_size.Text);//str转化成float类型，  取得字体大小
            textBox_note.Font = new Font(fontName, fontSize);//设置字体（包括 字体类型（名称）和 字体大小）
        }

        //通过 改变Text内容 更改字体大小
        private void toolStripComboBox_size_TextChanged(object sender, EventArgs e)
        {
            string fontName = toolStripComboBox_fonts.Text;//取得字体名称
            float fontSize = float.Parse(toolStripComboBox_size.Text);//str转化成float类型，  取得字体大小
            textBox_note.Font = new Font(fontName, fontSize);//设置字体（包括 字体类型（名称）和 字体大小）
        }

        //保存文档
        private void toolStripButton_save_Click(object sender, EventArgs e)
        {

            if (textBox_note.Text.Trim() != "")//如果内容不等于空，就保存
            {
                if (this.Text.Trim() == "")
                {
                    //新建一个保存文件的对话框  在设计窗口 添加
                    //创建一个筛选器，只能存  txt格式的
                    saveFileDialog.Filter = ("文本文档(*.txt)|*.txt");
                    //判断用户点击的是保存还是取消按钮
                    if (saveFileDialog.ShowDialog() == DialogResult.OK)
                    {
                        //保存文件到用户指定的目录位置
                        //获取用户选择的文件及路径
                        string path = saveFileDialog.FileName;
                        //保存文件到指定路径
                        StreamWriter sw = new StreamWriter(path, false);
                        sw.WriteLine(textBox_note.Text.Trim());//将 textBox编辑的内容  保存
                        //把窗体的text属性设置为保存后的文件路径
                        this.Text = path;
                        //保存文件时，清空记号标签
                        toolStripLabelmaker.Text = "";
                        sw.Flush();//清理缓存
                        sw.Close();//关闭
                    }
                }
                else
                {
                    //保存文件到用户指定的目录位置
                    //获取用户选择的文件及路径
                    string path = this.Text;
                    //保存文件到指定路径
                    StreamWriter sw = new StreamWriter(path, false);
                    sw.WriteLine(textBox_note.Text.Trim());//将 textBox编辑的内容  保存
                    toolStripLabelmaker.Text = "";
                    sw.Flush();//清理缓存
                    sw.Close();//关闭
                }
            }
            else
            {
                MessageBox.Show("文档为空！不能保存。", "信息提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        //打开文档
        private void toolStripButton_open_Click(object sender, EventArgs e)
        {
            //新建一个打开文件的对话框  在设计窗口 添加
            //创建一个筛选器，只能打开  txt格式的
            openFileDialog.Filter = ("文本文档(*.txt)|*.txt");
            //判断用户点击的是打开还是取消按钮
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                //获取要打开的文档的路径
                string path = openFileDialog.FileName;
                //通用编码UTF-8
                StreamReader sr = new StreamReader(path, Encoding.UTF8);
                //读取文档中的数据流
                string text = sr.ReadToEnd();
                textBox_note.Text = text;
                //将打开的文件路径写到当前窗体的text属性中
                this.Text = path;
                //打开文件时，清空记号标签
                toolStripLabelmaker.Text = "";
                sr.Close();//关闭
            }
        }

        //编辑文本时
        private void textBox_note_TextChanged(object sender, EventArgs e)//文本发生变化时
        {
            toolStripLabelmaker.Text = "*";
        }

        //窗体关闭事件
        private void Child_FormClosing(object sender, FormClosingEventArgs e)
        {
            //判断记号是否为 *号
            if(toolStripLabelmaker.Text == "*")//如果是*号，提示用户
            {
                //接受弹出信息框的返回值
                DialogResult dr = MessageBox.Show("文档尚未保存，确定要继续退出吗？", "信息询问", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if(dr==DialogResult.Yes)
                {
                    this.Dispose();//窗口释放掉
                }
                else
                {
                    e.Cancel = true;
                }
            }
        }

        //新建按钮
        private void toolStripButton_add_Click(object sender, EventArgs e)
        {
            textBox_note.Text = "";
            toolStripLabelmaker.Text = "";
            this.Text = "";
        }
    }
}
