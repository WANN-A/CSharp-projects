﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using WMPLib;

namespace Musicplayer
{
    public partial class Form1 : Form
    {
        //声明一个 list 用来存储文件的路径
        List<string> urlList = new List<string>();//泛型

        double max, min;

        public Form1()
        {
            InitializeComponent();
        }

        //添加歌曲
        private void buttonAddMusic_Click(object sender, EventArgs e)
        {
            OpenFileDialog of = new OpenFileDialog();//实例化 一个打开文件的对话框
            of.Multiselect = true;//让选择器同时选择多个文件
            of.Title = "请选择音乐文件";
            of.Filter = "(*.mp3)|*.mp3";//指定选择文件的类型

            if(of.ShowDialog()==DialogResult.OK)//选择 确定按钮
            {
                string[] nameList = of.FileNames;//把用户选择的文件 存到数组
                foreach(string url in nameList)//读取数组中的数据
                {
                    //Path.GetFileNameWithoutExtension(url) 获取不具有扩展名的文件名
                    listBoxMusics.Items.Add(Path.GetFileNameWithoutExtension(url));
                    urlList.Add(url);
                }
            }
        }

        //播放
        private void buttonPlay_Click(object sender, EventArgs e)
        {
            //声明变量
            int selectedIndex = listBoxMusics.SelectedIndex;
            if (selectedIndex < 0)
            {
                //判断列表是否有选中的歌曲，有的话播放选中的，没有的话播放第一首
                selectedIndex = listBoxMusics.SelectedIndex < 0 ? 0 : selectedIndex;

                //更新选中行
                listBoxMusics.SelectedIndex = selectedIndex;
                //把urlList中存储的url地址赋给播放器控件
                axWindowsMediaPlayer.URL = urlList[selectedIndex];
                labelMusicName.Text = listBoxMusics.SelectedItem.ToString();
            }
            else
            {
                axWindowsMediaPlayer.Ctlcontrols.play();//继续播放(暂停后)
            }
            timer.Enabled = true;
        }

        //暂停
        private void buttonPause_Click(object sender, EventArgs e)
        {
            axWindowsMediaPlayer.Ctlcontrols.pause();
        }

        //停止
        private void buttonStop_Click(object sender, EventArgs e)
        {
            axWindowsMediaPlayer.Ctlcontrols.stop();
            timer.Enabled = false;
        }

        //上一首
        private void buttonLast_Click(object sender, EventArgs e)
        {
            //ListBox中的索引和urlList中的索引 相对应
            //获取当前选中歌曲的索引 listBoxMusics.SelectedIndex
            int selectedIndex = listBoxMusics.SelectedIndex - 1;
            if (selectedIndex < 0)
                selectedIndex = 0;
            //更新选中行
            listBoxMusics.SelectedIndex = selectedIndex;
            //把urlList中存储的url地址赋给播放器控件
            axWindowsMediaPlayer.URL = urlList[selectedIndex];
            labelMusicName.Text = listBoxMusics.SelectedItem.ToString();
        }

        //下一首
        private void buttonNext_Click(object sender, EventArgs e)
        {
            //ListBox中的索引和urlList中的索引 相对应
            //获取当前选中歌曲的索引 listBoxMusics.SelectedIndex
            int selectedIndex = listBoxMusics.SelectedIndex + 1;
            selectedIndex = selectedIndex == listBoxMusics.Items.Count ? listBoxMusics.SelectedIndex : selectedIndex;
            //更新选中行
            listBoxMusics.SelectedIndex = selectedIndex;
            //把urlList中存储的url地址赋给播放器控件
            axWindowsMediaPlayer.URL = urlList[selectedIndex];
            labelMusicName.Text = listBoxMusics.SelectedItem.ToString();
        }

        //列表选择 发生变化时 播放选中的歌曲
        private void listBoxMusics_SelectedIndexChanged(object sender, EventArgs e)
        {
            //ListBox中的索引和urlList中的索引 相对应

            //获取当前选中歌曲的索引 listBoxMusics.SelectedIndex
            int selectedIndex = listBoxMusics.SelectedIndex;
            //把urlList中存储的url地址赋给播放器控件
            axWindowsMediaPlayer.URL = urlList[selectedIndex];
            labelMusicName.Text = listBoxMusics.SelectedItem.ToString();

            timer.Enabled = true;
        }

        private void timer_Tick(object sender, EventArgs e)
        {
            //获取文件的时间长度
            max = axWindowsMediaPlayer.currentMedia.duration;
            //获取当前歌曲的播放位置
            min = axWindowsMediaPlayer.Ctlcontrols.currentPosition;
            //类型强制转换
            trackBar.Maximum = (int)(max);//设置混动条的最大值
            trackBar.Value = (int)(min);//设置滚动条的当前值

            //一首歌播放完成后，继续下一首
            if(axWindowsMediaPlayer.playState==WMPPlayState.wmppsStopped)
            {
                //当前歌曲播放结束后，要获取下一首歌曲的索引值
                int selectedIndex = listBoxMusics.SelectedIndex + 1;
                //如果最后一首歌，播放完后放第一首歌；否则正常继续下一首
                selectedIndex = selectedIndex == listBoxMusics.Items.Count ? 0 : selectedIndex;

                axWindowsMediaPlayer.URL = urlList[selectedIndex];
                listBoxMusics.SelectedIndex = selectedIndex;
                labelMusicName.Text = listBoxMusics.SelectedItem.ToString();
                trackBar.Value = 0;
                trackBar.Enabled = true;
            }
        }

        //鼠标按下
        private void trackBar_MouseDown(object sender, MouseEventArgs e)
        {
            //暂停播放
            timer.Enabled = false;
            axWindowsMediaPlayer.Ctlcontrols.pause();
        }

        //鼠标抬起
        private void trackBar_MouseUp(object sender, MouseEventArgs e)
        {
            double value = trackBar.Value;//获取被拖动以后的位置
            axWindowsMediaPlayer.Ctlcontrols.currentPosition = value;//重置播放位置
            axWindowsMediaPlayer.Ctlcontrols.play();
            timer.Enabled = true;
        }

    }
}
