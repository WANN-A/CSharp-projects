﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 排块游戏
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        const int N = 3;//定义行数和列数
        Button[,] buttons = new Button[N, N];//按钮的数组

        private void Form1_Load(object sender, EventArgs e)
        {
            //生成所有按钮
            GenerateAllButtons();
        }

        void GenerateAllButtons()
        {
            int x0 = 100, y0 = 10, w = 45, d = 50;
            for(int r=0;r<N;r++)
            {
                for(int c=0;c<N;c++)
                {
                    int num = r * N + c;//行号加列号（从0开始）
                    Button btn = new Button();
                    btn.Text = (num + 1).ToString();

                    btn.Top = y0 + r * d;
                    btn.Left = x0 + c * d;
                    btn.Width = w;
                    btn.Height = w;
                    btn.Visible = true;
                    btn.Tag = r * N + c;//表示按钮 所在的行列位置

                    //注册事件
                    btn.Click += new EventHandler(btn_Click);

                    buttons[r, c] = btn;//放到数组中
                    this.Controls.Add(btn);//加到界面上
                }
                
            }
            buttons[N - 1, N - 1].Visible = false;//最后一个不显示（当作 空白的块）
        }

        void btn_Click(object sender,EventArgs e)
        {
            Button btn = sender as Button;//当前点击的按钮
            Button black = FindHiddenButton();//空白按钮

            //判断是否与空白块相邻，如果是，则交换
            if(IsNeighbor(btn,black))
            {
                Swap(btn, black);
                black.Focus();
            }

            //判断是否完成
            if(ResultIsOk())
            {
                MessageBox.Show("OK!");
            }
        }

        //查找空白按钮
        Button FindHiddenButton()
        {
            for(int r=0;r<N;r++)
            {
                for(int c=0;c<N;c++)
                {
                    if(!buttons[r,c].Visible)//通过遍历按钮数组，判断每个按钮的 是否可见  来判断空白按钮
                    {
                        return buttons[r, c];
                    }
                }
            }
            return null;
        }

        //判断是否相邻
        bool IsNeighbor(Button btna, Button btnb)
        {
            int a = (int)btna.Tag;//Tag记录了 行列位置
            int b = (int)btnb.Tag;
            int r1 = a / N, c1 = a % N;
            int r2 = b / N, c2 = b % N;

            if(r1==r2&&(c1==c2-1||c1==c2+1)//左右相邻（行号相等 并且 左右差一）
                ||c1==c2&&(r1==r2-1||r1==r2+1))//上下相邻
            {
                return true;
            }
            return false;

        }

        //判断是否完成
        bool ResultIsOk()
        {
            for(int r=0;r<N;r++)
            {
                for(int c=0;c<N;c++)
                {
                    if(buttons[r,c].Text!=(r*N+c+1).ToString())
                    {
                        return false;
                    }
                }
            }
            return true;
        }

        private void buttonStart_Click(object sender, EventArgs e)
        {
            //打乱顺序
            Shuffle();
        }

        void Shuffle()
        {
            //多次随机交换两个按钮（已到达打乱的作用）
            Random rnd = new Random();
            for(int i=0;i<100;i++)
            {
                int a = rnd.Next(N);
                int b = rnd.Next(N);
                int c = rnd.Next(N);
                int d = rnd.Next(N);
                Swap(buttons[a, b], buttons[c, d]);
            }
        }

        void Swap(Button btna,Button btnb)
        {
            //交换按钮的Text
            string t = btna.Text;
            btna.Text = btnb.Text;
            btnb.Text = t;

            //交换按钮的 是否可见
            bool v = btna.Visible;
            btna.Visible = btnb.Visible;
            btnb.Visible = v;
        }


    }
}
