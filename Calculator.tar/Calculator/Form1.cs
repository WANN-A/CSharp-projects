﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        float result;
        int i;//算术法则 用来判断
        
        //数字
        private void btn_1_Click(object sender, EventArgs e)
        {
            if (label_sym.Text == "?")
            {
                textBox_num1.Text += "1";
            }
            else
            {
                textBox_num2.Text += "1";
            }
        }

        private void btn_2_Click(object sender, EventArgs e)
        {
            if (label_sym.Text == "?")
            {
                textBox_num1.Text += "2";
            }
            else
            {
                textBox_num2.Text += "2";
            }
        }

        private void btn_3_Click(object sender, EventArgs e)
        {
            if (label_sym.Text == "?")
            {
                textBox_num1.Text += "3";
            }
            else
            {
                textBox_num2.Text += "3";
            }
        }

        private void btn_4_Click(object sender, EventArgs e)
        {
            if (label_sym.Text == "?")
            {
                textBox_num1.Text += "4";
            }
            else
            {
                textBox_num2.Text += "4";
            }
        }

        private void btn_5_Click(object sender, EventArgs e)
        {
            if (label_sym.Text == "?")
            {
                textBox_num1.Text += "5";
            }
            else
            {
                textBox_num2.Text += "5";
            }
        }

        private void btn_6_Click(object sender, EventArgs e)
        {
            if (label_sym.Text == "?")
            {
                textBox_num1.Text += "6";
            }
            else
            {
                textBox_num2.Text += "6";
            }
        }

        private void btn_7_Click(object sender, EventArgs e)
        {
            if (label_sym.Text == "?")
            {
                textBox_num1.Text += "7";
            }
            else
            {
                textBox_num2.Text += "7";
            }
        }

        private void btn_8_Click(object sender, EventArgs e)
        {
            if (label_sym.Text == "?")
            {
                textBox_num1.Text += "8";
            }
            else
            {
                textBox_num2.Text += "8";
            }
        }

        private void btn_9_Click(object sender, EventArgs e)
        {
            if (label_sym.Text == "?")
            {
                textBox_num1.Text += "9";
            }
            else
            {
                textBox_num2.Text += "9";
            }
        }

        private void btn_0_Click(object sender, EventArgs e)
        {
            if (label_sym.Text == "?")
            {
                textBox_num1.Text += "0";
            }
            else
            {
                textBox_num2.Text += "0";
            }
        }

        //点
        private void btn_dot_Click(object sender, EventArgs e)
        {
            if (label_sym.Text == "?")
            {
                textBox_num1.Text += ".";
            }
            else
            {
                textBox_num2.Text += ".";
            }
        }
     
        //算法
        private void btn_add_Click(object sender, EventArgs e)
        {
            label_sym.Text = "+";
            i = 1;
        }

        private void btn_sub_Click(object sender, EventArgs e)
        {
            label_sym.Text = "-";
            i = 2;
        }

        private void btn_mul_Click(object sender, EventArgs e)
        {
            label_sym.Text = "*";
            i = 3;
        }

        private void btn_dvi_Click(object sender, EventArgs e)
        {
            label_sym.Text = "/";
            i = 4;
        }

        private void btn_mod_Click(object sender, EventArgs e)
        {
            label_sym.Text = "%";
            i = 5;
        }

        private void button19_Click(object sender, EventArgs e)
        {
            label_sym.Text = "pow";
            i = 6;
        }
        private void btn_sqrt_Click(object sender, EventArgs e)
        {
            label_sym.Text = "sqrt";
            i = 7;
        }

        //结果
        private void btn_eqa_Click(object sender, EventArgs e)
        {
            switch(i)
            {
                case 1: 
                    result = Convert.ToSingle(textBox_num1.Text) + Convert.ToSingle(textBox_num2.Text);
                    textBox_result.Text=result.ToString();
                    break;
                case 2:
                    result = Convert.ToSingle(textBox_num1.Text) - Convert.ToSingle(textBox_num2.Text);
                    textBox_result.Text = result.ToString();
                    break;
                case 3:
                    result = Convert.ToSingle(textBox_num1.Text) * Convert.ToSingle(textBox_num2.Text);
                    textBox_result.Text = result.ToString();
                    break;
                case 4:
                    result = Convert.ToSingle(textBox_num1.Text) / Convert.ToSingle(textBox_num2.Text);
                    textBox_result.Text = result.ToString();
                    break;
                case 5:
                    result = Convert.ToSingle(textBox_num1.Text) % Convert.ToSingle(textBox_num2.Text);
                    textBox_result.Text = result.ToString();
                    break;
                case 6:
                    double res1 = Math.Pow(Convert.ToDouble(textBox_num1.Text),Convert.ToDouble(textBox_num2.Text));
                    textBox_result.Text = res1.ToString();
                    break;
                case 7:
                    double res2 = Math.Sqrt(Convert.ToDouble(textBox_num1.Text));
                    textBox_result.Text = res2.ToString();
                    break;
                default:
                    break;
            }
        }

        //其它按钮
        private void btn_clear_Click(object sender, EventArgs e)
        {
            label_sym.Text = "?";
            textBox_num1.Text = "";
            textBox_num2.Text = "";
            textBox_result.Text = "";
        }

      
    }
}
