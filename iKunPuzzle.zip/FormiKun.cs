﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace iKunPuzzle {
    public partial class FormiKun : Form {
        public FormiKun() {
            InitializeComponent();
        }

        // 文件路径
        string filePath = @"../../iKunPicture/";
        // 定义1~9的乱序数组
        int[] picInts = { 1, 2, 3, 4, 5, 6, 7, 8, 9 };

        /// <summary>
        /// 挑选图片事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSelect_Click(object sender, EventArgs e) {
            try {
                // 加载原图
                pbPic.Load(filePath + $@"iKun0{cbSelect.Text}/ikun.png");
                pbPic.BackgroundImageLayout = ImageLayout.Stretch;
                pbPic.SizeMode = PictureBoxSizeMode.StretchImage;

                // 加载分割图
                pb1.Load(filePath + $@"iKun0{cbSelect.Text}/1.png");
                pb2.Load(filePath + $@"iKun0{cbSelect.Text}/2.png");
                pb3.Load(filePath + $@"iKun0{cbSelect.Text}/3.png");
                pb4.Load(filePath + $@"iKun0{cbSelect.Text}/4.png");
                pb5.Load(filePath + $@"iKun0{cbSelect.Text}/5.png");
                pb6.Load(filePath + $@"iKun0{cbSelect.Text}/6.png");
                pb7.Load(filePath + $@"iKun0{cbSelect.Text}/7.png");
                pb8.Load(filePath + $@"iKun0{cbSelect.Text}/8.png");
                pb9.Load(filePath + $@"iKun0{cbSelect.Text}/9.png");
            } catch {
                MessageBox.Show("选择出错!", "ikun拼图", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// 开始 打乱图片顺序事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnStart_Click(object sender, EventArgs e) {
            DisruptPictureOrder();
        }

        /// <summary>
        /// 打乱图片顺序
        /// </summary>
        private void DisruptPictureOrder() {
            // 随机数
            Random random = new Random();
            // 打乱顺序
            for (int i = 0; i < picInts.Length; i++) {
                int temp = picInts[i];
                int index = random.Next(9);
                picInts[i] = picInts[index];
                picInts[index] = temp;
            }
            // 加载
            pb1.Load(filePath + $@"iKun0{cbSelect.Text}/{picInts[0]}.png");
            pb2.Load(filePath + $@"iKun0{cbSelect.Text}/{picInts[1]}.png");
            pb3.Load(filePath + $@"iKun0{cbSelect.Text}/{picInts[2]}.png");
            pb4.Load(filePath + $@"iKun0{cbSelect.Text}/{picInts[3]}.png");
            pb5.Load(filePath + $@"iKun0{cbSelect.Text}/{picInts[4]}.png");
            pb6.Load(filePath + $@"iKun0{cbSelect.Text}/{picInts[5]}.png");
            pb7.Load(filePath + $@"iKun0{cbSelect.Text}/{picInts[6]}.png");
            pb8.Load(filePath + $@"iKun0{cbSelect.Text}/{picInts[7]}.png");
            pb9.Load(filePath + $@"iKun0{cbSelect.Text}/{picInts[8]}.png");
        }

        /// <summary>
        /// 图片交换 事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void bnExchange_Click(object sender, EventArgs e) {
            PictureExchanged();
        }

        /// <summary>
        /// 图片交换
        /// </summary>
        private void PictureExchanged() {
            // 临时图片
            List<PictureBox> lstPics = new List<PictureBox>();
            PictureBox temp = new PictureBox();

            if (pb1.BorderStyle == BorderStyle.FixedSingle) {
                lstPics.Add(pb1);
            }

            if (pb2.BorderStyle == BorderStyle.FixedSingle) {
                lstPics.Add(pb2);
            }

            if (pb3.BorderStyle == BorderStyle.FixedSingle) {
                lstPics.Add(pb3);
            }

            if (pb4.BorderStyle == BorderStyle.FixedSingle) {
                lstPics.Add(pb4);
            }

            if (pb5.BorderStyle == BorderStyle.FixedSingle) {
                lstPics.Add(pb5);
            }

            if (pb6.BorderStyle == BorderStyle.FixedSingle) {
                lstPics.Add(pb6);
            }

            if (pb7.BorderStyle == BorderStyle.FixedSingle) {
                lstPics.Add(pb7);
            }

            if (pb8.BorderStyle == BorderStyle.FixedSingle) {
                lstPics.Add(pb8);
            }

            if (pb9.BorderStyle == BorderStyle.FixedSingle) {
                lstPics.Add(pb9);
            }

            if (lstPics.Count > 0) {
                temp.Image = lstPics[0].Image;
                temp.ImageLocation = lstPics[0].ImageLocation;
                lstPics[0].Image = lstPics[1].Image;
                lstPics[0].ImageLocation = lstPics[1].ImageLocation;
                lstPics[1].Image = temp.Image;
                lstPics[1].ImageLocation = temp.ImageLocation;
            }

            pb1.BorderStyle = BorderStyle.None;
            pb2.BorderStyle = BorderStyle.None;
            pb3.BorderStyle = BorderStyle.None;
            pb4.BorderStyle = BorderStyle.None;
            pb5.BorderStyle = BorderStyle.None;
            pb6.BorderStyle = BorderStyle.None;
            pb7.BorderStyle = BorderStyle.None;
            pb8.BorderStyle = BorderStyle.None;
            pb9.BorderStyle = BorderStyle.None;

            lstPics.Clear();
        }

        /// <summary>
        /// 选择分割图片事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void pb1_Click(object sender, EventArgs e) {
            pb1.BorderStyle = BorderStyle.FixedSingle;
        }

        private void pb2_Click(object sender, EventArgs e) {
            pb2.BorderStyle = BorderStyle.FixedSingle;
        }

        private void pb3_Click(object sender, EventArgs e) {
            pb3.BorderStyle = BorderStyle.FixedSingle;
        }

        private void pb4_Click(object sender, EventArgs e) {
            pb4.BorderStyle = BorderStyle.FixedSingle;
        }

        private void pb5_Click(object sender, EventArgs e) {
            pb5.BorderStyle = BorderStyle.FixedSingle;
        }

        private void pb6_Click(object sender, EventArgs e) {
            pb6.BorderStyle = BorderStyle.FixedSingle;
        }

        private void pb7_Click(object sender, EventArgs e) {
            pb7.BorderStyle = BorderStyle.FixedSingle;
        }

        private void pb8_Click(object sender, EventArgs e) {
            pb8.BorderStyle = BorderStyle.FixedSingle;
        }

        private void pb9_Click(object sender, EventArgs e) {
            pb9.BorderStyle = BorderStyle.FixedSingle;
        }

        /// <summary>
        /// 提交拼图事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnLoad_Click(object sender, EventArgs e) {
            JudgePictureComplete();
        }

        /// <summary>
        /// 判断图片是否拼完
        /// </summary>
        private void JudgePictureComplete() {
            if (pb1.ImageLocation == filePath + $@"iKun0{cbSelect.Text}/1.png" &&
                pb2.ImageLocation == filePath + $@"iKun0{cbSelect.Text}/2.png" &&
                pb3.ImageLocation == filePath + $@"iKun0{cbSelect.Text}/3.png" &&
                pb4.ImageLocation == filePath + $@"iKun0{cbSelect.Text}/4.png" &&
                pb5.ImageLocation == filePath + $@"iKun0{cbSelect.Text}/5.png" &&
                pb6.ImageLocation == filePath + $@"iKun0{cbSelect.Text}/6.png" &&
                pb7.ImageLocation == filePath + $@"iKun0{cbSelect.Text}/7.png" &&
                pb8.ImageLocation == filePath + $@"iKun0{cbSelect.Text}/8.png" &&
                pb9.ImageLocation == filePath + $@"iKun0{cbSelect.Text}/9.png") {
                MessageBox.Show("拼图完成！", "ikun拼图", MessageBoxButtons.OK, MessageBoxIcon.Information);
            } else {
                MessageBox.Show("还未完成！", "ikun拼图", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
}
