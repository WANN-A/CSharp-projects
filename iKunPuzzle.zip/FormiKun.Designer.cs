﻿namespace iKunPuzzle {
    partial class FormiKun {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent() {
            this.pbPic = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnSelect = new System.Windows.Forms.Button();
            this.btnStart = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pb3 = new System.Windows.Forms.PictureBox();
            this.pb2 = new System.Windows.Forms.PictureBox();
            this.pb9 = new System.Windows.Forms.PictureBox();
            this.pb8 = new System.Windows.Forms.PictureBox();
            this.pb7 = new System.Windows.Forms.PictureBox();
            this.pb6 = new System.Windows.Forms.PictureBox();
            this.pb5 = new System.Windows.Forms.PictureBox();
            this.pb4 = new System.Windows.Forms.PictureBox();
            this.pb1 = new System.Windows.Forms.PictureBox();
            this.cbSelect = new System.Windows.Forms.ComboBox();
            this.bnExchange = new System.Windows.Forms.Button();
            this.btnLoad = new System.Windows.Forms.Button();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            ((System.ComponentModel.ISupportInitialize)(this.pbPic)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb1)).BeginInit();
            this.SuspendLayout();
            // 
            // pbPic
            // 
            this.pbPic.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbPic.Location = new System.Drawing.Point(773, 50);
            this.pbPic.Name = "pbPic";
            this.pbPic.Size = new System.Drawing.Size(300, 300);
            this.pbPic.TabIndex = 1;
            this.pbPic.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("宋体", 12F);
            this.label1.Location = new System.Drawing.Point(892, 386);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 24);
            this.label1.TabIndex = 2;
            this.label1.Text = "原图";
            // 
            // btnSelect
            // 
            this.btnSelect.Location = new System.Drawing.Point(55, 738);
            this.btnSelect.Name = "btnSelect";
            this.btnSelect.Size = new System.Drawing.Size(117, 45);
            this.btnSelect.TabIndex = 4;
            this.btnSelect.Text = "选择图片";
            this.btnSelect.UseVisualStyleBackColor = true;
            this.btnSelect.Click += new System.EventHandler(this.btnSelect_Click);
            // 
            // btnStart
            // 
            this.btnStart.Location = new System.Drawing.Point(254, 738);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(117, 45);
            this.btnStart.TabIndex = 4;
            this.btnStart.Text = "开始";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.pb3);
            this.panel1.Controls.Add(this.pb2);
            this.panel1.Controls.Add(this.pb9);
            this.panel1.Controls.Add(this.pb8);
            this.panel1.Controls.Add(this.pb7);
            this.panel1.Controls.Add(this.pb6);
            this.panel1.Controls.Add(this.pb5);
            this.panel1.Controls.Add(this.pb4);
            this.panel1.Controls.Add(this.pb1);
            this.panel1.Location = new System.Drawing.Point(55, 49);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(618, 620);
            this.panel1.TabIndex = 5;
            // 
            // pb3
            // 
            this.pb3.Location = new System.Drawing.Point(412, 0);
            this.pb3.Name = "pb3";
            this.pb3.Size = new System.Drawing.Size(200, 200);
            this.pb3.TabIndex = 0;
            this.pb3.TabStop = false;
            this.pb3.Click += new System.EventHandler(this.pb3_Click);
            // 
            // pb2
            // 
            this.pb2.Location = new System.Drawing.Point(206, 0);
            this.pb2.Name = "pb2";
            this.pb2.Size = new System.Drawing.Size(200, 200);
            this.pb2.TabIndex = 0;
            this.pb2.TabStop = false;
            this.pb2.Click += new System.EventHandler(this.pb2_Click);
            // 
            // pb9
            // 
            this.pb9.Location = new System.Drawing.Point(412, 412);
            this.pb9.Name = "pb9";
            this.pb9.Size = new System.Drawing.Size(200, 200);
            this.pb9.TabIndex = 0;
            this.pb9.TabStop = false;
            this.pb9.Click += new System.EventHandler(this.pb9_Click);
            // 
            // pb8
            // 
            this.pb8.Location = new System.Drawing.Point(206, 412);
            this.pb8.Name = "pb8";
            this.pb8.Size = new System.Drawing.Size(200, 200);
            this.pb8.TabIndex = 0;
            this.pb8.TabStop = false;
            this.pb8.Click += new System.EventHandler(this.pb8_Click);
            // 
            // pb7
            // 
            this.pb7.Location = new System.Drawing.Point(0, 412);
            this.pb7.Name = "pb7";
            this.pb7.Size = new System.Drawing.Size(200, 200);
            this.pb7.TabIndex = 0;
            this.pb7.TabStop = false;
            this.pb7.Click += new System.EventHandler(this.pb7_Click);
            // 
            // pb6
            // 
            this.pb6.Location = new System.Drawing.Point(412, 206);
            this.pb6.Name = "pb6";
            this.pb6.Size = new System.Drawing.Size(200, 200);
            this.pb6.TabIndex = 0;
            this.pb6.TabStop = false;
            this.pb6.Click += new System.EventHandler(this.pb6_Click);
            // 
            // pb5
            // 
            this.pb5.Location = new System.Drawing.Point(206, 206);
            this.pb5.Name = "pb5";
            this.pb5.Size = new System.Drawing.Size(200, 200);
            this.pb5.TabIndex = 0;
            this.pb5.TabStop = false;
            this.pb5.Click += new System.EventHandler(this.pb5_Click);
            // 
            // pb4
            // 
            this.pb4.Location = new System.Drawing.Point(0, 206);
            this.pb4.Name = "pb4";
            this.pb4.Size = new System.Drawing.Size(200, 200);
            this.pb4.TabIndex = 0;
            this.pb4.TabStop = false;
            this.pb4.Click += new System.EventHandler(this.pb4_Click);
            // 
            // pb1
            // 
            this.pb1.Location = new System.Drawing.Point(0, 0);
            this.pb1.Name = "pb1";
            this.pb1.Size = new System.Drawing.Size(200, 200);
            this.pb1.TabIndex = 0;
            this.pb1.TabStop = false;
            this.pb1.Click += new System.EventHandler(this.pb1_Click);
            // 
            // cbSelect
            // 
            this.cbSelect.FormattingEnabled = true;
            this.cbSelect.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5"});
            this.cbSelect.Location = new System.Drawing.Point(88, 706);
            this.cbSelect.Name = "cbSelect";
            this.cbSelect.Size = new System.Drawing.Size(84, 26);
            this.cbSelect.TabIndex = 6;
            // 
            // bnExchange
            // 
            this.bnExchange.Location = new System.Drawing.Point(453, 738);
            this.bnExchange.Name = "bnExchange";
            this.bnExchange.Size = new System.Drawing.Size(117, 45);
            this.bnExchange.TabIndex = 4;
            this.bnExchange.Text = "交换";
            this.bnExchange.UseVisualStyleBackColor = true;
            this.bnExchange.Click += new System.EventHandler(this.bnExchange_Click);
            // 
            // btnLoad
            // 
            this.btnLoad.Location = new System.Drawing.Point(652, 738);
            this.btnLoad.Name = "btnLoad";
            this.btnLoad.Size = new System.Drawing.Size(117, 45);
            this.btnLoad.TabIndex = 4;
            this.btnLoad.Text = "提交";
            this.btnLoad.UseVisualStyleBackColor = true;
            this.btnLoad.Click += new System.EventHandler(this.btnLoad_Click);
            // 
            // richTextBox1
            // 
            this.richTextBox1.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.richTextBox1.Location = new System.Drawing.Point(773, 493);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.ReadOnly = true;
            this.richTextBox1.Size = new System.Drawing.Size(300, 169);
            this.richTextBox1.TabIndex = 7;
            this.richTextBox1.Text = "规则：\n（1）使用鼠标选择两张图片，然后进行交换。\n（2）当错乱的图片完全与原图一致时，拼图完成！";
            // 
            // FormiKun
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1125, 815);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.cbSelect);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btnLoad);
            this.Controls.Add(this.bnExchange);
            this.Controls.Add(this.btnStart);
            this.Controls.Add(this.btnSelect);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pbPic);
            this.MaximumSize = new System.Drawing.Size(1147, 871);
            this.MinimumSize = new System.Drawing.Size(1147, 871);
            this.Name = "FormiKun";
            this.Text = "iKun 拼图";
            ((System.ComponentModel.ISupportInitialize)(this.pbPic)).EndInit();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pb3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.PictureBox pbPic;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnSelect;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pb3;
        private System.Windows.Forms.PictureBox pb2;
        private System.Windows.Forms.PictureBox pb9;
        private System.Windows.Forms.PictureBox pb8;
        private System.Windows.Forms.PictureBox pb7;
        private System.Windows.Forms.PictureBox pb6;
        private System.Windows.Forms.PictureBox pb5;
        private System.Windows.Forms.PictureBox pb4;
        private System.Windows.Forms.PictureBox pb1;
        private System.Windows.Forms.ComboBox cbSelect;
        private System.Windows.Forms.Button bnExchange;
        private System.Windows.Forms.Button btnLoad;
        private System.Windows.Forms.RichTextBox richTextBox1;
    }
}

